import React, { useState } from "react";
import "./App.css";

function App() {
  const [count, setCount] = useState(0);

  return (
    <div className="counter-container">
      <h1>Click Counter App</h1>
      <h2>{count}</h2>

      <button onClick={() => setCount(count + 1)}>Increase</button>
      <button onClick={() => setCount(count > 0 ? count - 1 : 0)}>Decrease</button>

      {count === 10 && <p>You've reached the limit!</p>}
    </div>
  );
}

export default App;
